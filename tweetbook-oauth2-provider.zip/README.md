OAuth2 Provider Demo
--------------------

- Build the standalone Mule application with `mvn package`
- After deployment, browse to: [http://localhost:8084/bookstore]() 
- The username/password login doesn't work, use "Sign-in with Your TweetBook Account" to trigger the OAuth2 dance.
- Use john/doe to login on TweetBook.
